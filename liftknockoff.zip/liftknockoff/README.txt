Sources:
https://github.com/tomchentw/react-google-maps/issues/414
https://stackoverflow.com/questions/9713058/send-post-data-using-xmlhttprequest
https://developers.google.com/maps/documentation/javascript/tutorial

Python LocalHost: python3 -m http.server